import urax_adb as adb

adb.devices()
adb.execute("adb help")